from django.apps import AppConfig


class ContactsAppConfig(AppConfig):
    name = 'Contacts_app'
