$(document).ready(function () {
    $("#send").click(function () {
        var obj = {
            name: $("#name").val(),
            phone_number: $("#phone_number").val(),
            home_number: $("#home_number").val(),
            address: $("#address").val()
        };
        var json = JSON.stringify(obj);
        sendData(json);
        window.location.pathname = "/contacts/save/";
    });
});


function sendData(json) {
    $.ajax({
        url: 'http://127.0.0.1:8000/contacts/save/',
        type: 'POST',
        data: json,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        headers: {
            'Csrf-Token': '@helper.CSRF.getToken.value'
        },
        async: false,
        success: function(msg) {
            console.log("successful" + msg);
        }
    });
}