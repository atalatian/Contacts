from django.db import models


class Record(models.Model):
    name = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=255)
    home_number = models.CharField(max_length=255)
    address = models.TextField()
