from django.contrib import admin
from Contacts_app.models import Record

# Register your models here.
admin.site.register(Record)
