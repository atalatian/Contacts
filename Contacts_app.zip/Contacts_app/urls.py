from django.urls import path, include
from . import views

urlpatterns = [
    path("contacts/", views.render_index, name="render_index"),
    path("contacts/save/", views.set_record, name="set_record"),
    path("records/", views.print_records, name="print_records"),
]