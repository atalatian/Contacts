from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status
import io
from rest_framework.decorators import api_view
from rest_framework.parsers import JSONParser
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from .models import Record
from .serializers import RecordSerializer


@api_view(["POST", "GET"])
def render_index(request):
    return render(request,"Contacts_app/index.html")


@csrf_exempt
@api_view(["POST","GET"])
def set_record(request):
    if request.method == "POST":
        stream = io.BytesIO(request.body)
        data = JSONParser().parse(stream)
        serializer = RecordSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
    if request.method == "GET":
        return HttpResponseRedirect(reverse('print_records'))


@api_view(["GET", "POST"])
def print_records(request):
    if request.method == "GET":
        records = Record.objects.all()
        serializer = RecordSerializer(records, many=True)
        return Response(serializer.data)
